import os
# 获取exe/脚本所在目录
base_path = os.path.dirname(os.path.abspath(__file__))
# 指定PaddleX缓存目录为exe同目录下的.paddlex
os.environ['PADDLEX_HOME'] = os.path.join(base_path, ".paddlex")

# 再写下面的import，顺序不能颠倒！
from paddleocr import PaddleOCR
# -*- coding: utf-8 -*-
"""
成绩自动录入辅助工具 - 主程序 (v1.5)
修复：
- 去掉嵌套 wait_window，改用回调，解决新建个人成绩后卡死
- get_existing_records_from_excel 增加最大行数保护
"""

import sys
import os
import json
import threading
import time
from pathlib import Path
from typing import List, Optional, Dict, Any
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk

# 导入自定义模块
from grade_tool.config import load_config, SUPPORTED_FORMATS, get_exam_type_standard
from grade_tool.models import (
    ScoreRecord, ValidationResult, PhoneMessage, PhoneResponse,
    ExamType, DuplicateAction, LogEntry, Student
)
from grade_tool.logger import log_manager

# 可选导入OCR和Excel处理库
try:
    from rapidocr_onnxruntime import RapidOCR
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False
    print("警告：RapidOCR 未安装，OCR 功能将不可用")

try:
    from paddleocr import PaddleOCR
    PADDLE_OCR_AVAILABLE = True
except ImportError:
    PADDLE_OCR_AVAILABLE = False
    print("警告：PaddleOCR 未安装，请先执行 pip install paddleocr")

try:
    import openpyxl
    import pandas as pd
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False
    print("警告：openpyxl/pandas 未安装，Excel 功能将不可用")

try:
    import serial
    import serial.tools.list_ports
    SERIAL_AVAILABLE = True
except ImportError:
    SERIAL_AVAILABLE = False
    print("警告：pyserial 未安装，手机端通信功能将不可用")


use_multithread = True
EXCEL_MAX_SCAN_ROWS = 5000   # get_existing_records_from_excel 最多扫描的行数，防止异常文件卡死


class GradeEntryTool:
    """成绩自动录入辅助工具主类"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("成绩自动录入辅助工具 v1.5")
        self.root.geometry("1200x880")
        self.root.resizable(True, True)

        self.config = load_config()
        self.current_excel_path = ""
        self.excel_data = None
        self.ocr_results = []
        self.validation_result = ValidationResult(is_valid=True)
        self.phone_serial = None
        self.phone_thread = None
        self.phone_running = False

        self.imported_files = []
        self.ocr_ready = False
        self._ocr_lock = threading.Lock()
        self._ocr_running = False

        # 记录当前打开的 edit_window 引用，避免重复打开
        self._edit_window = None

        if use_multithread:
            self.paddle_ocr = None
            self.create_widgets()
            if hasattr(self, 'status_var'):
                self.status_var.set("正在加载OCR模型，请稍候...")
            self.ocr_load_thread = threading.Thread(
                target=self._load_ocr_model_background, daemon=True
            )
            self.ocr_load_thread.start()
        else:
            self.paddle_ocr = PaddleOCR(use_textline_orientation=True, lang="ch")
            self.ocr_ready = True
            log_manager.log_info("PaddleOCR 引擎初始化成功（CPU模式，简体中文）")
            self.create_widgets()

    def _load_ocr_model_background(self):
        try:
            paddle_ocr = PaddleOCR(use_textline_orientation=True, lang="ch")
            log_manager.log_info("PaddleOCR 引擎初始化成功（CPU模式，简体中文）")
            self.root.after(0, lambda: self._on_ocr_model_ready(paddle_ocr))
        except Exception as e:
            error_msg = f"OCR模型加载失败: {e}"
            log_manager.log_error("PaddleOCR 引擎初始化失败", e)
            self.root.after(0, lambda: self._on_ocr_model_failed(error_msg))

    def _on_ocr_model_ready(self, paddle_ocr):
        self.paddle_ocr = paddle_ocr
        self.ocr_ready = True
        if hasattr(self, 'recognize_btn'):
            self.recognize_btn.config(state=tk.NORMAL)
        self.status_var.set("OCR模型加载完成，就绪")

    def _on_ocr_model_failed(self, error_msg):
        if hasattr(self, 'recognize_btn'):
            self.recognize_btn.config(state=tk.NORMAL)
        self.status_var.set(error_msg)

    def create_widgets(self):
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_panel = ttk.LabelFrame(main_frame, text="控制面板", width=320)
        left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_panel.pack_propagate(False)

        right_panel = ttk.Frame(main_frame)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.create_control_panel(left_panel)
        self.create_display_area(right_panel)

    def create_control_panel(self, parent):
        excel_frame = ttk.LabelFrame(parent, text="Excel文件")
        excel_frame.pack(fill=tk.X, padx=5, pady=5)

        ttk.Button(excel_frame, text="选择Excel文件",
                   command=self.select_excel_file).pack(fill=tk.X, padx=5, pady=5)

        self.excel_label = ttk.Label(excel_frame, text="未选择文件", foreground="gray")
        self.excel_label.pack(fill=tk.X, padx=5, pady=2)

        subject_row_frame = ttk.LabelFrame(parent, text="科目写入的序号")
        subject_row_frame.pack(fill=tk.X, padx=5, pady=5)

        ttk.Label(subject_row_frame,
                  text="Excel 表头所在行号（留空=自动扫描）:",
                  foreground="gray").pack(anchor=tk.W, padx=5, pady=2)
        self.subject_row_var = tk.StringVar(value="")
        ttk.Entry(subject_row_frame, textvariable=self.subject_row_var,
                  width=20).pack(fill=tk.X, padx=5, pady=5)

        name_col_frame = ttk.LabelFrame(parent, text="姓名开头的列数")
        name_col_frame.pack(fill=tk.X, padx=5, pady=5)

        ttk.Label(name_col_frame,
                  text="每行姓名从第几个块开始（留空=1）:",
                  foreground="gray").pack(anchor=tk.W, padx=5, pady=2)
        self.name_start_col_var = tk.StringVar(value="")
        ttk.Entry(name_col_frame, textvariable=self.name_start_col_var,
                  width=20).pack(fill=tk.X, padx=5, pady=5)

        import_frame = ttk.LabelFrame(parent, text="文件导入")
        import_frame.pack(fill=tk.X, padx=5, pady=5)

        ttk.Button(import_frame, text="导入图片/PDF",
                   command=self.import_files).pack(fill=tk.X, padx=5, pady=5)

        self.import_label = ttk.Label(import_frame, text="未导入文件", foreground="gray")
        self.import_label.pack(fill=tk.X, padx=5, pady=2)

        exam_frame = ttk.LabelFrame(parent, text="考试类型")
        exam_frame.pack(fill=tk.X, padx=5, pady=5)

        self.exam_var = tk.StringVar()
        exam_combo = ttk.Combobox(exam_frame, textvariable=self.exam_var, state="readonly")
        exam_combo['values'] = list(self.config.get("exam_type_mapping", {}).keys()) or [
            "周测", "第一次月考", "第二次月考", "第三次月考", "期中", "期末", "模拟考", "其他"
        ]
        exam_combo.pack(fill=tk.X, padx=5, pady=5)
        exam_combo.bind("<<ComboboxSelected>>", self.on_exam_type_changed)

        subject_frame = ttk.LabelFrame(parent, text="科目")
        subject_frame.pack(fill=tk.X, padx=5, pady=5)

        self.subject_var = tk.StringVar()
        subject_combo = ttk.Combobox(subject_frame, textvariable=self.subject_var, state="readonly")
        subject_combo['values'] = self.config.get("standard_subjects", []) or [
            "语文", "数学", "英语", "物理", "化学", "生物", "历史", "地理", "政治",
            "电子", "计算机", "编程", "电工", "电子技术", "单片机", "PLC"
        ]
        subject_combo.pack(fill=tk.X, padx=5, pady=5)
        subject_combo.bind("<<ComboboxSelected>>", self.on_subject_changed)

        preview_frame = ttk.LabelFrame(parent, text="OCR识别结果")
        preview_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.preview_text = tk.Text(preview_frame, height=6, wrap=tk.WORD)
        preview_scroll = ttk.Scrollbar(preview_frame, orient=tk.VERTICAL, command=self.preview_text.yview)
        self.preview_text.configure(yscrollcommand=preview_scroll.set)
        self.preview_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(5, 0), pady=5)
        preview_scroll.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 5), pady=5)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=10)

        self.recognize_btn = ttk.Button(btn_frame, text="开始识别",
                                        command=self.start_ocr_recognition)
        self.recognize_btn.pack(fill=tk.X, pady=2)
        if use_multithread and not self.ocr_ready:
            self.recognize_btn.config(state=tk.DISABLED)

        ttk.Button(btn_frame, text="手动纠错",
                   command=self.edit_ocr_result).pack(fill=tk.X, pady=2)
        ttk.Button(btn_frame, text="确认录入",
                   command=self.confirm_entry).pack(fill=tk.X, pady=2)
        ttk.Button(btn_frame, text="手机端开关",
                   command=self.toggle_phone_sync).pack(fill=tk.X, pady=2)

        status_frame = ttk.LabelFrame(parent, text="状态")
        status_frame.pack(fill=tk.X, padx=5, pady=5)

        self.status_var = tk.StringVar(value="就绪")
        ttk.Label(status_frame, textvariable=self.status_var, foreground="blue").pack(
            fill=tk.X, padx=5, pady=5)

    def create_display_area(self, parent):
        notebook = ttk.Notebook(parent)
        notebook.pack(fill=tk.BOTH, expand=True)

        grade_frame = ttk.Frame(notebook)
        notebook.add(grade_frame, text="成绩表格")

        self.tree = ttk.Treeview(grade_frame, show="headings")
        tree_scroll_y = ttk.Scrollbar(grade_frame, orient=tk.VERTICAL, command=self.tree.yview)
        tree_scroll_x = ttk.Scrollbar(grade_frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=tree_scroll_y.set, xscrollcommand=tree_scroll_x.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        tree_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)

        log_frame = ttk.Frame(notebook)
        notebook.add(log_frame, text="操作日志")

        self.log_text = tk.Text(log_frame, wrap=tk.WORD, state=tk.DISABLED)
        log_scroll = ttk.Scrollbar(log_frame, orient=tk.VERTICAL, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scroll.set)
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(5, 0), pady=5)
        log_scroll.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 5), pady=5)

        self.refresh_logs()

    # ---------------- 文本清洗 ----------------
    def _clean_cell_text(self, value):
        if value is None:
            return ""
        s = str(value)
        s = s.replace('\u3000', ' ')
        s = s.replace('\n', '').replace('\r', '').replace('\t', '')
        s = ''.join(ch for ch in s if ch.isprintable() or ch == ' ')
        return s.strip()

    def _get_manual_subject_row(self):
        raw = ""
        try:
            raw = self.subject_row_var.get().strip()
        except Exception:
            return None
        if not raw:
            return None
        try:
            n = int(raw)
            return n if n >= 1 else None
        except ValueError:
            return None

    def _get_manual_name_start_col(self):
        raw = ""
        try:
            raw = self.name_start_col_var.get().strip()
        except Exception:
            return 1
        if not raw:
            return 1
        try:
            n = int(raw)
            return n if n >= 1 else 1
        except ValueError:
            return 1

    # ---------------- Excel相关 ----------------
    def select_excel_file(self):
        if not EXCEL_AVAILABLE:
            messagebox.showerror("错误", "Excel 处理库未安装，请安装 openpyxl 和 pandas")
            return

        file_path = filedialog.askopenfilename(
            title="选择Excel成绩文件",
            filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")]
        )
        if file_path:
            try:
                self.current_excel_path = file_path
                self.excel_label.config(text=os.path.basename(file_path), foreground="black")
                self.load_excel_data()
                filename = os.path.basename(file_path)
                self.auto_detect_exam_type_from_filename(filename)
                self.status_var.set(f"已加载Excel文件: {filename}")
                log_manager.log_info(f"加载Excel文件: {file_path}")
            except Exception as e:
                log_manager.log_error("加载Excel文件失败", e)
                messagebox.showerror("错误", f"加载Excel文件失败: {e}")

    def load_excel_data(self):
        try:
            df = pd.read_excel(self.current_excel_path)
            self.excel_data = df
            self.update_treeview()
        except Exception as e:
            raise Exception(f"读取Excel失败: {e}")

    def update_treeview(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        if self.excel_data is None or self.excel_data.empty:
            return
        columns = list(self.excel_data.columns)
        self.tree["columns"] = columns
        self.tree["show"] = "headings"
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)
        for idx, row in self.excel_data.iterrows():
            values = [str(row[col]) if pd.notna(row[col]) else "" for col in columns]
            self.tree.insert("", "end", values=values, tags=(str(idx),))

    def import_files(self):
        file_paths = filedialog.askopenfilenames(
            title="选择图片或PDF文件",
            filetypes=[
                ("图片文件", "*.jpg *.jpeg *.png *.bmp *.webp"),
                ("PDF文件", "*.pdf"),
                ("所有支持文件", "*.jpg *.jpeg *.png *.bmp *.webp *.pdf")
            ]
        )
        if file_paths:
            self.imported_files = list(file_paths)
            file_names = [os.path.basename(f) for f in file_paths]
            self.import_label.config(
                text=f"已导入 {len(file_names)} 个文件", foreground="black"
            )
            self.status_var.set(f"已导入 {len(file_names)} 个文件")
            log_manager.log_info(f"导入文件: {', '.join(file_names)}")

    def on_exam_type_changed(self, event=None):
        selected = self.exam_var.get()
        self.status_var.set(f"考试类型: {selected}")

    def on_subject_changed(self, event=None):
        selected = self.subject_var.get()
        self.status_var.set(f"科目: {selected}")

    def auto_detect_exam_type_from_filename(self, filename):
        name_without_ext = os.path.splitext(filename)[0]
        exam_type_mapping = self.config.get("exam_type_mapping", {})
        for standard_type, variants in exam_type_mapping.items():
            for variant in variants:
                if variant in name_without_ext:
                    self.exam_var.set(standard_type)
                    return
        if not self.exam_var.get():
            self.exam_var.set("其他")

    def find_subject_column(self, worksheet, subject_name):
        try:
            target = self._clean_cell_text(subject_name)
            if not target:
                return None

            manual_row = self._get_manual_subject_row()
            if manual_row is not None and manual_row <= worksheet.max_row:
                header_row = manual_row
                print(f"[Excel调试] 使用用户指定的表头行: {header_row}")
            else:
                header_row = 1
                if manual_row is not None:
                    print(f"[Excel调试] 用户指定的行号 {manual_row} 超出范围，回退到第1行")

            headers = []
            for col in range(1, worksheet.max_column + 1):
                raw = worksheet.cell(row=header_row, column=col).value
                headers.append((col, self._clean_cell_text(raw)))

            print(f"[Excel调试] 表头行{header_row} 清洗结果: {headers}")
            print(f"[Excel调试] 目标科目(清洗后): {target!r}")

            for col, header in headers:
                if header == target:
                    print(f"[Excel调试] 精确匹配命中: 列{col} = {header!r}")
                    return col

            candidates = []
            for col, header in headers:
                if header and target in header:
                    candidates.append((len(header), col, header))
            if candidates:
                candidates.sort()
                _, best_col, best_header = candidates[0]
                print(f"[Excel调试] 包含匹配命中: 列{best_col} = {best_header!r}")
                return best_col

            print(f"[Excel调试] 未找到科目列: {target!r}")
            return None
        except Exception as e:
            print(f"[Excel调试] find_subject_column异常: {e}")
            return None

    def get_existing_records_from_excel(self):
        try:
            if not EXCEL_AVAILABLE or not self.current_excel_path:
                return []
            wb = openpyxl.load_workbook(self.current_excel_path, read_only=True, data_only=True)
            ws = wb.active

            manual_row = self._get_manual_subject_row()
            if manual_row is not None and manual_row <= ws.max_row:
                header_row = manual_row
            else:
                header_row = 1

            subject_cols = {}
            for col in range(2, ws.max_column + 1):
                header = self._clean_cell_text(ws.cell(row=header_row, column=col).value)
                if header:
                    subject_cols[col] = header
            if not subject_cols:
                wb.close()
                return []

            # 上限保护：防止异常文件把 max_row 撑得很大导致卡死
            last_row = min(ws.max_row, header_row + EXCEL_MAX_SCAN_ROWS)

            exam_type = self.exam_var.get()
            records = []
            for row in range(header_row + 1, last_row + 1):
                name = self._clean_cell_text(ws.cell(row=row, column=1).value)
                if not name:
                    continue
                for col, subject in subject_cols.items():
                    value = ws.cell(row=row, column=col).value
                    value_clean = self._clean_cell_text(value)
                    if value_clean:
                        records.append(ScoreRecord(
                            student_name=name, subject=subject,
                            exam_type=exam_type, score=value_clean, source="excel"
                        ))
            wb.close()
            return records
        except Exception as e:
            log_manager.log_error("读取Excel现有记录失败", e)
            return []

    def _write_record_to_worksheet(self, ws, record):
        manual_row = self._get_manual_subject_row()
        if manual_row is not None and manual_row <= ws.max_row:
            header_row = manual_row
        else:
            header_row = 1

        target_row = None
        target_name = self._clean_cell_text(record.student_name)
        for row in range(header_row + 1, ws.max_row + 1):
            cell_value = self._clean_cell_text(ws.cell(row=row, column=1).value)
            if cell_value and cell_value == target_name:
                target_row = row
                break
        if target_row is None:
            target_row = ws.max_row + 1
            ws.cell(row=target_row, column=1, value=record.student_name)

        subject_col = self.find_subject_column(ws, record.subject)
        if not subject_col:
            log_manager.log_warning(f"Excel中未找到科目列: {record.subject}")
            return False
        ws.cell(row=target_row, column=subject_col, value=record.score)
        return True

    def write_records_to_excel(self, records):
        success_count = 0
        fail_count = 0
        try:
            if not EXCEL_AVAILABLE or not self.current_excel_path:
                messagebox.showerror("错误", "Excel功能不可用或未加载Excel文件")
                return 0, len(records)
            wb = openpyxl.load_workbook(self.current_excel_path)
            ws = wb.active
            for record in records:
                try:
                    if self._write_record_to_worksheet(ws, record):
                        log_manager.log_insert(record, "user", "通过成绩录入工具录入")
                        success_count += 1
                    else:
                        fail_count += 1
                except Exception as e:
                    log_manager.log_error(f"录入记录失败: {record}", e)
                    fail_count += 1
            wb.save(self.current_excel_path)
        except Exception as e:
            log_manager.log_error("批量写入Excel失败", e)
            return 0, len(records)
        return success_count, fail_count

    def write_record_to_excel(self, record):
        try:
            if not EXCEL_AVAILABLE or not self.current_excel_path:
                return False
            wb = openpyxl.load_workbook(self.current_excel_path)
            ws = wb.active
            if not self._write_record_to_worksheet(ws, record):
                return False
            wb.save(self.current_excel_path)
            return True
        except Exception as e:
            log_manager.log_error(f"写入Excel记录失败: {record}", e)
            return False

    # ---------------- 校验相关 ----------------
    def validate_records(self):
        if not self.ocr_results:
            messagebox.showwarning("警告", "没有OCR结果可校验")
            return ValidationResult(is_valid=False, errors=["没有OCR结果"])
        if self.excel_data is None:
            messagebox.showwarning("警告", "请先加载Excel文件")
            return ValidationResult(is_valid=False, errors=["请先加载Excel文件"])
        validation = ValidationResult(is_valid=True)
        if self.config.get("validation", {}).get("filename_match_enabled", True):
            filename_validation = self.validate_filename_match()
            if not filename_validation.is_valid:
                validation.is_valid = False
                validation.errors.extend(filename_validation.errors)
            validation.warnings.extend(filename_validation.warnings)
        if self.config.get("validation", {}).get("duplicate_check_enabled", True):
            duplicate_validation = self.validate_duplicates()
            if not duplicate_validation.is_valid:
                validation.is_valid = False
                validation.errors.extend(duplicate_validation.errors)
            validation.warnings.extend(duplicate_validation.warnings)
            validation.duplicate_records = duplicate_validation.duplicate_records
        name_validation = self.validate_duplicate_names()
        if not name_validation.is_valid:
            validation.is_valid = False
            validation.errors.extend(name_validation.errors)
        validation.warnings.extend(name_validation.warnings)
        validation.duplicate_names = name_validation.duplicate_names
        self.validation_result = validation
        return validation

    def validate_single_record(self, record):
        validation = ValidationResult(is_valid=True)
        if self.excel_data is None:
            validation.is_valid = False
            validation.errors.append("电脑端未加载Excel文件，无法校验")
            return validation
        for existing in self.get_existing_records_from_excel():
            if (existing.student_name == record.student_name
                    and existing.subject == record.subject):
                validation.is_valid = False
                validation.errors.append(
                    f"重复成绩: {record.student_name} 的 {record.subject} 已有成绩 {existing.score}"
                )
                break
        return validation

    def validate_filename_match(self):
        validation = ValidationResult(is_valid=True)
        if not self.current_excel_path:
            validation.is_valid = False
            validation.errors.append("未加载Excel文件")
            return validation
        filename = os.path.basename(self.current_excel_path)
        name_without_ext = os.path.splitext(filename)[0]
        exam_type = self.exam_var.get()
        if exam_type and exam_type not in name_without_ext:
            validation.is_valid = False
            validation.warnings.append(
                f"文件名 '{filename}' 中未检测到考试类型 '{exam_type}' "
                f"(可能是特殊命名，可手动强行录入)"
            )
        return validation

    def validate_duplicates(self):
        validation = ValidationResult(is_valid=True)
        if self.excel_data is None:
            return validation
        duplicate_records = []
        existing_records = self.get_existing_records_from_excel()
        for ocr_record in self.ocr_results:
            key = ocr_record.get_key()
            for existing_record in existing_records:
                if existing_record.get_key() == key:
                    duplicate_records.append((ocr_record, existing_record))
        if duplicate_records:
            validation.is_valid = False
            validation.duplicate_records = [pair[0] for pair in duplicate_records]
            action = self.config.get("validation", {}).get("duplicate_action", "ask")
            if action == "ask":
                validation.warnings.append(
                    f"发现 {len(duplicate_records)} 条重复成绩记录，请选择处理方式"
                )
            elif action == "overwrite":
                validation.warnings.append(
                    f"将覆盖 {len(duplicate_records)} 条重复成绩记录"
                )
            elif action == "skip":
                validation.warnings.append(
                    f"将跳过 {len(duplicate_records)} 条重复成绩记录"
                )
        return validation

    def validate_duplicate_names(self):
        validation = ValidationResult(is_valid=True)
        if self.excel_data is None:
            return validation
        name_counts = {}
        for record in self.ocr_results:
            name_counts[record.student_name] = name_counts.get(record.student_name, 0) + 1
        duplicate_names = [name for name, count in name_counts.items() if count > 1]
        if duplicate_names:
            validation.is_valid = False
            validation.warnings.append(
                f"发现重名学生: {', '.join(duplicate_names)}，请人工确认录入对象"
            )
            validation.duplicate_names = [Student(name=name) for name in duplicate_names]
        return validation

    def confirm_entry(self):
        validation = self.validate_records()
        if not validation.is_valid:
            error_msg = "校验失败:\n" + "\n".join(validation.errors)
            if validation.warnings:
                error_msg += "\n\n警告:\n" + "\n".join(validation.warnings)
            result = messagebox.askyesnocancel(
                "校验失败",
                error_msg + "\n\n是否继续录入？\n"
                            "是：强行录入\n"
                            "否：取消录入\n"
                            "取消：查看详细信息"
            )
            if result is True:
                pass
            elif result is False:
                return
            else:
                self.show_validation_details(validation)
                return
        elif validation.warnings:
            warning_msg = "校验通过，但有警告:\n" + "\n".join(validation.warnings)
            result = messagebox.askyesno("确认录入", warning_msg + "\n\n是否继续录入？")
            if not result:
                return
        self.perform_grade_entry(validation)

    def show_validation_details(self, validation):
        detail_window = tk.Toplevel(self.root)
        detail_window.title("校验详细信息")
        detail_window.geometry("500x400")
        text = tk.Text(detail_window, wrap=tk.WORD)
        text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        content = "=== 校验结果 ===\n"
        content += f"是否通过: {'是' if validation.is_valid else '否'}\n\n"
        if validation.errors:
            content += "=== 错误 ===\n"
            for error in validation.errors:
                content += f"✗ {error}\n"
            content += "\n"
        if validation.warnings:
            content += "=== 警告 ===\n"
            for warning in validation.warnings:
                content += f"⚠ {warning}\n"
            content += "\n"
        if validation.duplicate_records:
            content += f"=== 重复记录 ({len(validation.duplicate_records)}条) ===\n"
            for record in validation.duplicate_records:
                content += (
                    f"{record.student_name} | {record.subject} | "
                    f"{record.exam_type} = {record.score}\n"
                )
            content += "\n"
        if validation.duplicate_names:
            content += f"=== 重名学生 ({len(validation.duplicate_names)}名) ===\n"
            for student in validation.duplicate_names:
                content += f"{student.name}\n"
            content += "\n"
        text.insert(tk.END, content)
        text.config(state=tk.DISABLED)
        ttk.Button(detail_window, text="关闭", command=detail_window.destroy).pack(pady=10)

    def perform_grade_entry(self, validation):
        if not EXCEL_AVAILABLE or self.excel_data is None:
            messagebox.showerror("错误", "Excel功能不可用或未加载Excel文件")
            return
        records_to_entry = self.ocr_results.copy()
        if validation.duplicate_records:
            duplicate_action = self.config.get("validation", {}).get("duplicate_action", "ask")
            if duplicate_action == "ask":
                action = self.ask_duplicate_action(len(validation.duplicate_records))
                if action == "cancel":
                    return
                elif action == "skip":
                    duplicate_keys = {r.get_key() for r in validation.duplicate_records}
                    records_to_entry = [
                        r for r in records_to_entry if r.get_key() not in duplicate_keys
                    ]
            elif duplicate_action == "overwrite":
                pass
        success_count, fail_count = self.write_records_to_excel(records_to_entry)
        self.load_excel_data()
        result_msg = f"录入完成！\n成功: {success_count}条\n失败: {fail_count}条"
        if fail_count > 0:
            messagebox.showwarning("录入结果", result_msg)
        else:
            messagebox.showinfo("录入结果", result_msg)
        self.status_var.set(f"录入完成: 成功{success_count}条, 失败{fail_count}条")
        if messagebox.askyesno("清理", "是否清空已录入的OCR结果？"):
            self.ocr_results = []
            self.update_ocr_preview()

    def ask_duplicate_action(self, count):
        dialog = tk.Toplevel(self.root)
        dialog.title("处理重复记录")
        dialog.geometry("300x200")
        dialog.transient(self.root)
        dialog.grab_set()
        ttk.Label(dialog, text=f"发现 {count} 条重复成绩记录，请选择处理方式：").pack(pady=20)
        result = tk.StringVar(value="ask")
        ttk.Radiobutton(dialog, text="覆盖旧成绩", variable=result, value="overwrite").pack(anchor=tk.W, padx=20)
        ttk.Radiobutton(dialog, text="跳过本条记录", variable=result, value="skip").pack(anchor=tk.W, padx=20)
        ttk.Radiobutton(dialog, text="取消录入", variable=result, value="cancel").pack(anchor=tk.W, padx=20)
        def confirm():
            dialog.destroy()
        ttk.Button(dialog, text="确定", command=confirm).pack(pady=20)
        self.root.wait_window(dialog)
        return result.get()

    # ---------------- OCR识别核心 ----------------
    def start_ocr_recognition(self):
        if not self.imported_files:
            messagebox.showwarning("警告", "请先导入图片或PDF文件")
            return
        if not self.paddle_ocr:
            messagebox.showerror("错误", "OCR 引擎未初始化")
            return
        if use_multithread and not self.ocr_ready:
            messagebox.showwarning("警告", "OCR模型正在加载中，请稍候...")
            return
        if not self.exam_var.get():
            messagebox.showwarning("警告", "请选择考试类型")
            return
        if not self.subject_var.get():
            messagebox.showwarning("警告", "请选择科目")
            return
        if self._ocr_running:
            messagebox.showwarning("警告", "已有识别任务正在进行，请稍候")
            return
        self._ocr_running = True
        self.recognize_btn.config(state=tk.DISABLED)
        if use_multithread:
            self.status_var.set("正在进行OCR识别...")
            thread = threading.Thread(target=self.perform_ocr_recognition, daemon=True)
            thread.start()
        else:
            self.perform_ocr_recognition()

    def perform_ocr_recognition(self):
        try:
            all_records = []
            self.ocr_results = []
            for i, file_path in enumerate(self.imported_files):
                self.root.after(
                    0,
                    lambda idx=i, total=len(self.imported_files):
                    self.status_var.set(f"正在识别第 {idx+1}/{total} 个文件...")
                )
                if file_path.lower().endswith('.pdf'):
                    records = self.process_pdf_file(file_path)
                else:
                    records = self.process_image_file(file_path)
                all_records.extend(records)
                self.ocr_results = all_records.copy()
                self.root.after(0, self.update_ocr_preview)
            self.ocr_results = all_records
            self.root.after(0, self.update_ocr_preview)
            self.root.after(
                0,
                lambda: self.status_var.set(f"OCR识别完成，共识别 {len(all_records)} 条记录")
            )
            log_manager.log_info(
                f"OCR识别完成，处理 {len(self.imported_files)} 个文件，识别 {len(all_records)} 条记录"
            )
        except Exception as e:
            error_msg = f"OCR识别失败: {e}"
            self.root.after(0, lambda: self.status_var.set(error_msg))
            self.root.after(0, lambda: messagebox.showerror("错误", error_msg))
            log_manager.log_error("OCR识别失败", e)
        finally:
            self._ocr_running = False
            self.root.after(0, lambda: self.recognize_btn.config(state=tk.NORMAL))

    def _normalize_ocr_result(self, result):
        normalized = []
        for page in (result or []):
            if not page:
                continue
            if hasattr(page, "get") or isinstance(page, dict):
                try:
                    texts = page.get("rec_texts")
                    scores = page.get("rec_scores")
                    polys = page.get("rec_polys")
                    if texts is None:
                        normalized.append(page)
                        continue
                    lines = []
                    for i in range(len(texts)):
                        box = polys[i].tolist() if hasattr(polys[i], "tolist") else polys[i]
                        lines.append([box, (str(texts[i]), float(scores[i]))])
                    normalized.append(lines)
                    continue
                except (TypeError, ValueError, IndexError):
                    normalized.append(page)
                    continue
            normalized.append(page)
        return normalized

    def _run_ocr(self, img):
        # 用带超时的 acquire，避免死锁永久阻塞
        acquired = self._ocr_lock.acquire(timeout=120)
        if not acquired:
            raise RuntimeError("OCR锁获取超时，可能有其他识别任务卡住了")
        try:
            try:
                return self.paddle_ocr.ocr(img)
            except TypeError:
                return self.paddle_ocr.ocr(img, cls=True)
        finally:
            self._ocr_lock.release()

    def process_image_file(self, file_path):
        try:
            result = self._run_ocr(file_path)
            if not result:
                log_manager.log_warning(f"OCR未识别到任何内容: {file_path}")
                return []

            MIN_CONFIDENCE = self.config.get("ocr", {}).get("confidence_threshold", 0.3)
            result = self._normalize_ocr_result(result)

            name_start_col = self._get_manual_name_start_col()
            print(f"[OCR调试] 用户指定姓名起始列: {name_start_col}")

            raw_blocks = []
            blocks = []
            heights = []
            for page in result:
                if not page:
                    continue
                for line in page:
                    try:
                        box = line[0]
                        text = str(line[1][0]).strip()
                        conf = float(line[1][1])
                        raw_blocks.append((text, conf))
                        if not text or conf < MIN_CONFIDENCE:
                            continue
                        y_avg = (box[0][1] + box[2][1]) / 2
                        x_avg = (box[0][0] + box[1][0]) / 2
                        blocks.append({"y": y_avg, "x": x_avg, "text": text, "conf": conf})
                        heights.append(abs(box[2][1] - box[0][1]))
                    except (ValueError, TypeError, IndexError):
                        continue

            print(f"[OCR调试] ===== 原始识别 {len(raw_blocks)} 个块 (阈值={MIN_CONFIDENCE}) =====")
            for text, conf in raw_blocks:
                flag = "✓" if conf >= MIN_CONFIDENCE else "✗过滤"
                print(f"  {flag} conf={conf:.3f} text={text!r}")

            if not blocks:
                log_manager.log_warning(f"OCR结果全部被置信度过滤: {file_path}")
                return []

            median_h = sorted(heights)[len(heights) // 2] if heights else 20
            y_threshold = max(median_h * 0.8, 20)
            print(f"[OCR调试] 中位行高={median_h:.1f}, y聚类阈值={y_threshold:.1f}")

            sorted_blocks = sorted(blocks, key=lambda b: b["y"])
            rows = []
            current_row = None
            for blk in sorted_blocks:
                if current_row is None:
                    current_row = {"base_y": blk["y"], "blocks": [blk]}
                    rows.append(current_row)
                    continue
                if abs(blk["y"] - current_row["base_y"]) < y_threshold:
                    current_row["blocks"].append(blk)
                    ys = [b["y"] for b in current_row["blocks"]]
                    current_row["base_y"] = sum(ys) / len(ys)
                else:
                    current_row = {"base_y": blk["y"], "blocks": [blk]}
                    rows.append(current_row)

            print(f"[OCR调试] 共分为 {len(rows)} 行")
            for ri, row in enumerate(rows):
                texts = [b["text"] for b in row["blocks"]]
                print(f"[OCR调试] 行{ri}: Y={row['base_y']:.1f}, 块={texts}")

            exam_type = self.exam_var.get()
            subject = self.subject_var.get()
            standard_subjects = self.config.get("standard_subjects", [])

            def is_header_text(text):
                t = text.strip()
                if not t:
                    return False
                if subject and subject in t:
                    return True
                for ss in standard_subjects:
                    if ss and ss in t:
                        return True
                if t in ("姓名", "学生", "学号", "序号", "分数", "成绩", "科目"):
                    return True
                return False

            def row_has_numbers(blocks_list):
                for b in blocks_list:
                    t = b["text"].strip().replace(",", "").replace("，", "")
                    if t.isdigit():
                        return True
                return False

            header_row_idx = None
            header_subject = None
            for idx in range(len(rows)):
                row_texts = [b["text"].strip() for b in rows[idx]["blocks"]]
                if any(is_header_text(t) for t in row_texts) and not row_has_numbers(rows[idx]["blocks"]):
                    header_row_idx = idx
                    for t in row_texts:
                        if subject and subject in t:
                            header_subject = subject
                            break
                        for ss in standard_subjects:
                            if ss and ss in t:
                                header_subject = ss
                                break
                        if header_subject:
                            break
                    break

            if header_row_idx is None:
                header_row_idx = 0

            final_subject = header_subject or subject
            print(
                f"[OCR调试] 表头行={header_row_idx}, 表头科目={header_subject!r}, "
                f"使用科目={final_subject!r}"
            )

            def looks_like_score(t):
                if not t:
                    return False
                clean = t.replace(",", "").replace("，", "").replace(" ", "").rstrip("%")
                try:
                    v = float(clean)
                    return 0 <= v <= 1500
                except ValueError:
                    return False

            def looks_like_name(t):
                if not t or len(t) > 10:
                    return False
                has_chinese = any('\u4e00' <= ch <= '\u9fa5' for ch in t)
                if not has_chinese:
                    return False
                clean = t.replace(".", "").replace(" ", "")
                return not clean.isdigit()

            records = []
            for ri in range(header_row_idx + 1, len(rows)):
                row = rows[ri]
                blks = sorted(row["blocks"], key=lambda b: b["x"])

                if name_start_col > 1:
                    if len(blks) >= name_start_col:
                        blks = blks[name_start_col - 1:]
                    else:
                        print(f"[OCR调试] 行{ri} 块数={len(blks)} < 姓名起始列{name_start_col}，跳过本行")
                        continue

                texts = [b["text"].strip() for b in blks]
                print(f"[OCR调试] >>数据行{ri}: {texts}")

                i = 0
                row_hit = 0
                while i < len(blks):
                    name_text = blks[i]["text"].strip()
                    if not looks_like_name(name_text):
                        i += 1
                        continue

                    score_text = None
                    score_idx = None
                    for j in range(i + 1, min(i + 6, len(blks))):
                        if looks_like_score(blks[j]["text"]):
                            score_text = blks[j]["text"]
                            score_idx = j
                            break

                    if score_text is None:
                        print(f"[OCR调试] 行{ri} 姓名 {name_text!r} 后面5个块内找不到分数，跳过")
                        i += 1
                        continue

                    score_clean = score_text.replace(",", "").replace("，", "").strip()
                    try:
                        records.append(ScoreRecord(
                            student_name=name_text,
                            subject=final_subject,
                            exam_type=exam_type,
                            score=score_clean,
                            raw_ocr=f"{name_text} {score_text}",
                            source="ocr"
                        ))
                        row_hit += 1
                        print(f"[OCR调试] 行{ri} 解析: {name_text} -> {score_clean}")
                    except Exception as e:
                        print(f"[OCR调试] 行{ri} 创建记录失败: {e}")

                    i = score_idx + 1

                print(f"[OCR调试] <<行{ri} 得到 {row_hit} 条")

            log_manager.log_info(f"图片OCR解析完成: {file_path}，提取 {len(records)} 条记录")
            print(f"[OCR调试] ===== 解析完成: {file_path}，共 {len(records)} 条 =====")
            return records

        except Exception as e:
            log_manager.log_error(f"处理图片文件失败: {file_path}", e)
            return []

    def process_pdf_file(self, file_path):
        try:
            log_manager.log_warning(f"PDF处理功能尚未完全实现: {file_path}")
            return []
        except Exception as e:
            log_manager.log_error(f"处理PDF文件失败: {file_path}", e)
            return []

    def update_ocr_preview(self):
        self.preview_text.delete(1.0, tk.END)
        if not self.ocr_results:
            self.preview_text.insert(tk.END, "未识别到任何记录\n")
            return
        preview_content = ""
        for i, record in enumerate(self.ocr_results, 1):
            preview_content += (
                f"{i}. {record.student_name} | {record.subject} | "
                f"{record.exam_type} | {record.score}\n"
            )
            preview_content += f"   原始OCR: {record.raw_ocr}\n\n"
        self.preview_text.insert(tk.END, preview_content)

    # ---------------- 手动纠错 / 新建 ----------------
    def edit_ocr_result(self):
        """手动纠错窗口（不用嵌套 wait_window，改用回调刷新，避免卡死）"""
        # 避免重复打开
        if self._edit_window is not None and self._edit_window.winfo_exists():
            self._edit_window.lift()
            return

        edit_window = tk.Toplevel(self.root)
        self._edit_window = edit_window
        edit_window.title("手动纠错OCR结果")
        edit_window.geometry("700x450")
        edit_window.transient(self.root)

        tree = ttk.Treeview(
            edit_window,
            columns=("姓名", "科目", "考试类型", "分数", "原始OCR"),
            show="headings"
        )
        tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        tree.heading("姓名", text="姓名")
        tree.heading("科目", text="科目")
        tree.heading("考试类型", text="考试类型")
        tree.heading("分数", text="分数")
        tree.heading("原始OCR", text="原始OCR")

        def refresh_tree():
            try:
                for item in tree.get_children():
                    tree.delete(item)
                for i, record in enumerate(self.ocr_results):
                    tree.insert("", "end", values=(
                        record.student_name, record.subject,
                        record.exam_type, record.score, record.raw_ocr
                    ), tags=(i,))
            except Exception as e:
                print(f"[手动纠错] 刷新列表失败: {e}")

        refresh_tree()

        btn_frame = ttk.Frame(edit_window)
        btn_frame.pack(fill=tk.X, padx=10, pady=5)

        def edit_selected():
            selection = tree.selection()
            if not selection:
                messagebox.showwarning("警告", "请选择要编辑的记录")
                return
            item = tree.item(selection[0])
            index = int(item["tags"][0])
            record = self.ocr_results[index]
            self.create_edit_dialog(edit_window, record, index, tree)

        def add_new_record():
            # 关键：不用 wait_window，通过回调刷新
            self._open_add_record_dialog(edit_window, on_success=refresh_tree)

        ttk.Button(btn_frame, text="编辑选中项", command=edit_selected).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="删除选中项",
                   command=lambda: self.delete_record(tree)).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="➕ 新建个人成绩",
                   command=add_new_record).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="确定",
                   command=edit_window.destroy).pack(side=tk.RIGHT, padx=5)

        # 处理窗口关闭
        def on_close():
            self._edit_window = None
            edit_window.destroy()
        edit_window.protocol("WM_DELETE_WINDOW", on_close)

    def _open_add_record_dialog(self, parent, on_success=None):
        """新建个人成绩对话框。
        关键修复：不使用 wait_window，通过 on_success 回调刷新父窗口列表。
        """
        dialog = tk.Toplevel(parent)
        dialog.title("新建个人成绩")
        dialog.geometry("420x320")
        dialog.transient(parent)
        dialog.grab_set()

        default_subject = self.subject_var.get().strip() or "语文"
        default_exam = self.exam_var.get().strip() or "其他"

        ttk.Label(dialog, text="姓名：").grid(row=0, column=0, sticky=tk.W, padx=15, pady=10)
        name_var = tk.StringVar(value="")
        name_entry = ttk.Entry(dialog, textvariable=name_var, width=28)
        name_entry.grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(dialog, text="成绩：").grid(row=1, column=0, sticky=tk.W, padx=15, pady=10)
        score_var = tk.StringVar(value="")
        ttk.Entry(dialog, textvariable=score_var, width=28).grid(
            row=1, column=1, padx=10, pady=10)

        ttk.Label(dialog, text="科目：").grid(row=2, column=0, sticky=tk.W, padx=15, pady=10)
        subject_var = tk.StringVar(value=default_subject)
        subject_values = self.config.get("standard_subjects", []) or [
            "语文", "数学", "英语", "物理", "化学", "生物", "历史", "地理", "政治",
            "电子", "计算机", "编程", "电工", "电子技术", "单片机", "PLC"
        ]
        ttk.Combobox(dialog, textvariable=subject_var,
                     values=subject_values, width=26).grid(
            row=2, column=1, padx=10, pady=10)

        ttk.Label(dialog, text="考试类型：").grid(row=3, column=0, sticky=tk.W, padx=15, pady=10)
        exam_var = tk.StringVar(value=default_exam)
        exam_values = list(self.config.get("exam_type_mapping", {}).keys()) or [
            "周测", "第一次月考", "第二次月考", "第三次月考", "期中", "期末", "模拟考", "其他"
        ]
        ttk.Combobox(dialog, textvariable=exam_var,
                     values=exam_values, width=26).grid(
            row=3, column=1, padx=10, pady=10)

        name_entry.focus_set()

        def on_save():
            name = name_var.get().strip()
            score = score_var.get().strip()
            subject = subject_var.get().strip()
            exam_type = exam_var.get().strip()

            if not name:
                messagebox.showwarning("警告", "姓名不能为空", parent=dialog)
                return
            if not score:
                messagebox.showwarning("警告", "成绩不能为空", parent=dialog)
                return
            if not subject:
                messagebox.showwarning("警告", "科目不能为空", parent=dialog)
                return

            try:
                float(score.replace(",", "").replace("，", ""))
            except ValueError:
                messagebox.showwarning("警告", f"成绩 '{score}' 不是合法数字", parent=dialog)
                return

            try:
                new_record = ScoreRecord(
                    student_name=name,
                    subject=subject,
                    exam_type=exam_type,
                    score=score,
                    raw_ocr=f"[手动新建] {name} {score}",
                    source="manual"
                )
                self.ocr_results.append(new_record)
                log_manager.log_info(f"手动新建成绩: {name} | {subject} | {score}")
                print(f"[手动新建] 追加记录: {name} | {subject} | {exam_type} | {score}")

                # 刷新主界面预览
                self.update_ocr_preview()

                # 回调刷新父窗口的列表
                if on_success is not None:
                    try:
                        on_success()
                    except Exception as e:
                        print(f"[手动新建] 回调刷新失败: {e}")

                dialog.destroy()
            except Exception as e:
                log_manager.log_error("手动新建记录失败", e)
                messagebox.showerror("错误", f"新建失败: {e}", parent=dialog)

        def on_cancel():
            dialog.destroy()

        dialog.bind("<Return>", lambda e: on_save())
        dialog.protocol("WM_DELETE_WINDOW", on_cancel)

        btn_frame = ttk.Frame(dialog)
        btn_frame.grid(row=4, column=0, columnspan=2, pady=20)
        ttk.Button(btn_frame, text="保存", command=on_save).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="取消", command=on_cancel).pack(side=tk.RIGHT, padx=10)
        # 注意：这里没有 wait_window，函数直接返回

    def create_edit_dialog(self, parent, record, index, tree):
        dialog = tk.Toplevel(parent)
        dialog.title("编辑记录")
        dialog.geometry("400x300")
        dialog.transient(parent)
        dialog.grab_set()
        ttk.Label(dialog, text="学生姓名:").grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)
        name_var = tk.StringVar(value=record.student_name)
        ttk.Entry(dialog, textvariable=name_var, width=30).grid(row=0, column=1, padx=10, pady=5)
        ttk.Label(dialog, text="科目:").grid(row=1, column=0, sticky=tk.W, padx=10, pady=5)
        subject_var = tk.StringVar(value=record.subject)
        ttk.Entry(dialog, textvariable=subject_var, width=30).grid(row=1, column=1, padx=10, pady=5)
        ttk.Label(dialog, text="考试类型:").grid(row=2, column=0, sticky=tk.W, padx=10, pady=5)
        exam_var = tk.StringVar(value=record.exam_type)
        ttk.Entry(dialog, textvariable=exam_var, width=30).grid(row=2, column=1, padx=10, pady=5)
        ttk.Label(dialog, text="分数:").grid(row=3, column=0, sticky=tk.W, padx=10, pady=5)
        score_var = tk.StringVar(value=record.score)
        ttk.Entry(dialog, textvariable=score_var, width=30).grid(row=3, column=1, padx=10, pady=5)
        ttk.Label(dialog, text="原始OCR:").grid(row=4, column=0, sticky=tk.W, padx=10, pady=5)
        ttk.Label(dialog, text=record.raw_ocr, foreground="gray").grid(
            row=4, column=1, sticky=tk.W, padx=10, pady=5)
        btn_frame = ttk.Frame(dialog)
        btn_frame.grid(row=5, column=0, columnspan=2, pady=20)

        def save_changes():
            record.student_name = name_var.get().strip()
            record.subject = subject_var.get().strip()
            record.exam_type = exam_var.get().strip()
            record.score = score_var.get().strip()
            selection = tree.selection()
            if selection:
                tree.item(selection[0], values=(
                    record.student_name, record.subject,
                    record.exam_type, record.score, record.raw_ocr
                ))
            self.update_ocr_preview()
            dialog.destroy()
            messagebox.showinfo("成功", "记录已更新", parent=parent)

        ttk.Button(btn_frame, text="保存", command=save_changes).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="取消", command=dialog.destroy).pack(side=tk.RIGHT, padx=5)

    def delete_record(self, tree):
        selection = tree.selection()
        if not selection:
            messagebox.showwarning("警告", "请选择要删除的记录")
            return
        if messagebox.askyesno("确认", "确定要删除选中的记录吗？"):
            item = tree.item(selection[0])
            index = int(item["tags"][0])
            del self.ocr_results[index]
            tree.delete(selection[0])
            self.update_ocr_preview()

    # ---------------- 手机端通信相关 ----------------
    def start_phone_listener(self):
        if not SERIAL_AVAILABLE:
            log_manager.log_warning("手机端通信功能不可用：pyserial 未安装")
            return
        try:
            port_config = self.config.get("phone_sync", {})
            port = port_config.get("port", "COM3")
            baudrate = port_config.get("baudrate", 115200)
            timeout = port_config.get("timeout", 1)
            self.phone_serial = serial.Serial(port, baudrate, timeout=timeout)
            self.phone_running = True
            self.phone_thread = threading.Thread(target=self.phone_listener_loop, daemon=True)
            self.phone_thread.start()
            log_manager.log_info(f"手机端监听已启动: {port} @ {baudrate}baud")
            self.status_var.set(f"手机端已连接: {port}")
        except Exception as e:
            log_manager.log_error("手机端监听启动失败", e)
            self.phone_serial = None
            self.phone_running = False
            messagebox.showwarning("警告", f"手机端通信启动失败: {e}\n请检查USB连接和端口设置")

    def phone_listener_loop(self):
        buffer = ""
        while self.phone_running and self.phone_serial:
            try:
                if self.phone_serial.in_waiting > 0:
                    data = self.phone_serial.read(self.phone_serial.in_waiting).decode(
                        'utf-8', errors='ignore')
                    buffer += data
                    while '\n' in buffer:
                        line, buffer = buffer.split('\n', 1)
                        line = line.strip()
                        if line:
                            self.process_phone_message(line)
                time.sleep(0.1)
            except Exception as e:
                if self.phone_running:
                    log_manager.log_error("手机端通信错误", e)
                break
        if self.phone_serial:
            try:
                self.phone_serial.close()
            except:
                pass
            self.phone_serial = None

    def process_phone_message(self, json_str):
        try:
            phone_msg = PhoneMessage.from_json(json_str)
            self.root.after(0, self.handle_phone_message, phone_msg)
        except Exception as e:
            log_manager.log_error(f"处理手机端消息失败: {json_str}", e)
            self.send_phone_response(PhoneResponse(status="error", warn="消息解析失败"))

    def handle_phone_message(self, phone_msg):
        try:
            self.exam_var.set(phone_msg.exam_type)
            self.subject_var.set(phone_msg.subject)
            record = ScoreRecord(
                student_name=phone_msg.student_name,
                subject=phone_msg.subject,
                exam_type=phone_msg.exam_type,
                score=phone_msg.score,
                raw_ocr=phone_msg.raw_ocr,
                phone_time=phone_msg.time,
                source="phone"
            )
            validation = self.validate_single_record(record)
            if validation.is_valid or not validation.has_error():
                if self.write_record_to_excel(record):
                    response = PhoneResponse(status="ok", warn="")
                    log_manager.log_insert(record, "phone", "通过手机端USB录入")
                else:
                    response = PhoneResponse(status="warn", warn="Excel写入失败")
            else:
                warn_msg = "; ".join(validation.errors[:2])
                response = PhoneResponse(
                    status="warn_dup_record" if "重复" in str(validation.errors)
                    else "warn_dup_name",
                    warn=warn_msg
                )
            self.send_phone_response(response)
        except Exception as e:
            log_manager.log_error("处理手机端消息异常", e)
            self.send_phone_response(PhoneResponse(status="error", warn="处理异常"))

    def send_phone_response(self, response):
        if self.phone_serial and self.phone_serial.is_open:
            try:
                response_str = response.to_json()
                self.phone_serial.write(response_str.encode('utf-8'))
                log_manager.log_info(f"发送手机端响应: {response.status}")
            except Exception as e:
                log_manager.log_error("发送手机端响应失败", e)

    def toggle_phone_sync(self):
        if self.phone_running:
            self.stop_phone_listener()
        else:
            if SERIAL_AVAILABLE:
                self.start_phone_listener()
            else:
                messagebox.showwarning("警告", "手机端通信功能不可用：请安装 pyserial")

    def stop_phone_listener(self):
        self.phone_running = False
        if self.phone_thread:
            self.phone_thread.join(timeout=2)
        if self.phone_serial:
            try:
                self.phone_serial.close()
            except:
                pass
            self.phone_serial = None
        log_manager.log_info("手机端监听已停止")
        self.status_var.set("手机端已断开")

    # ---------------- 日志刷新与退出 ----------------
    def refresh_logs(self):
        try:
            logs = log_manager.get_recent_logs(1)
            self.log_text.config(state=tk.NORMAL)
            self.log_text.delete(1.0, tk.END)
            for log in logs[-50:]:
                timestamp = log.get("timestamp", "")
                action = log.get("action", "")
                operator = log.get("operator", "")
                details = log.get("details", "")
                log_line = f"[{timestamp}] [{action}] [{operator}] {details}\n"
                self.log_text.insert(tk.END, log_line)
            self.log_text.config(state=tk.DISABLED)
            self.log_text.see(tk.END)
        except Exception as e:
            print(f"刷新日志失败: {e}")
        self.root.after(5000, self.refresh_logs)

    def on_closing(self):
        if messagebox.askokcancel("退出", "确定要退出成绩录入辅助工具吗？"):
            self.stop_phone_listener()
            self.root.destroy()

    def run(self):
        self.root.mainloop()


def main():
    try:
        app = GradeEntryTool()
        app.run()
    except Exception as e:
        print(f"程序启动失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()