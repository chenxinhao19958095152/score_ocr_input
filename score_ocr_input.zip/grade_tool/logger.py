# -*- coding: utf-8 -*-
"""
成绩自动录入辅助工具 - 日志管理模块
"""
import os
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional
from logging.handlers import RotatingFileHandler

from .config import LOG_DIR, load_config
from .models import LogEntry, ScoreRecord


class LogManager:
    """日志管理器"""
    
    def __init__(self):
        self.config = load_config()
        self.log_dir = LOG_DIR
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # 设置日志文件
        self.log_file = self.log_dir / f"grade_tool_{datetime.now().strftime('%Y%m%d')}.log"
        self.operation_log_file = self.log_dir / f"operations_{datetime.now().strftime('%Y%m%d')}.jsonl"
        
        # 配置标准日志
        self.logger = logging.getLogger("GradeTool")
        self.logger.setLevel(getattr(logging, self.config["logging"]["level"]))
        
        # 避免重复添加handler
        if not self.logger.handlers:
            # 文件handler（带轮转）
            file_handler = RotatingFileHandler(
                self.log_file,
                maxBytes=self.config["logging"]["max_file_size"],
                backupCount=self.config["logging"]["backup_count"],
                encoding="utf-8"
            )
            file_handler.setFormatter(logging.Formatter(
                "%(asctime)s - %(levelname)s - %(message)s"
            ))
            self.logger.addHandler(file_handler)
            
            # 控制台handler
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(logging.Formatter(
                "%(asctime)s - %(levelname)s - %(message)s"
            ))
            self.logger.addHandler(console_handler)
    
    def log_operation(self, entry: LogEntry):
        """记录操作日志"""
        try:
            # 写入JSONL文件（便于后续分析）
            with open(self.operation_log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")
            
            # 写入标准日志
            self.logger.info(f"[{entry.action}] {entry.operator} - {entry.details}")
            
        except Exception as e:
            self.logger.error(f"日志记录失败: {e}")
    
    def log_insert(self, record: ScoreRecord, operator: str = "user", details: str = ""):
        """记录插入操作"""
        entry = LogEntry(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            action="insert",
            operator=operator,
            record=record,
            details=details or f"新增成绩: {record.student_name} - {record.subject} - {record.exam_type} = {record.score}"
        )
        self.log_operation(entry)
    
    def log_update(self, old_record: ScoreRecord, new_record: ScoreRecord, operator: str = "user", details: str = ""):
        """记录更新操作"""
        entry = LogEntry(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            action="update",
            operator=operator,
            record=new_record,
            old_record=old_record,
            details=details or f"修改成绩: {new_record.student_name} - {new_record.subject} - {new_record.exam_type} : {old_record.score} -> {new_record.score}"
        )
        self.log_operation(entry)
    
    def log_overwrite(self, old_record: ScoreRecord, new_record: ScoreRecord, operator: str = "user", details: str = ""):
        """记录覆盖操作"""
        entry = LogEntry(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            action="overwrite",
            operator=operator,
            record=new_record,
            old_record=old_record,
            details=details or f"覆盖成绩: {new_record.student_name} - {new_record.subject} - {new_record.exam_type} : {old_record.score} -> {new_record.score}"
        )
        self.log_operation(entry)
    
    def log_skip(self, record: ScoreRecord, operator: str = "user", details: str = ""):
        """记录跳过操作"""
        entry = LogEntry(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            action="skip",
            operator=operator,
            record=record,
            details=details or f"跳过录入: {record.student_name} - {record.subject} - {record.exam_type}"
        )
        self.log_operation(entry)
    
    def log_import(self, records: List[ScoreRecord], source_file: str, operator: str = "system"):
        """记录批量导入操作"""
        for record in records:
            entry = LogEntry(
                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                action="import",
                operator=operator,
                record=record,
                details=f"从 {source_file} 导入: {record.student_name} - {record.subject} - {record.exam_type} = {record.score}"
            )
            self.log_operation(entry)
    
    def log_error(self, message: str, exception: Exception = None):
        """记录错误"""
        error_msg = message
        if exception:
            error_msg += f" - {type(exception).__name__}: {exception}"
        self.logger.error(error_msg)
    
    def log_warning(self, message: str):
        """记录警告"""
        self.logger.warning(message)
    
    def log_info(self, message: str):
        """记录信息"""
        self.logger.info(message)
    
    def get_recent_logs(self, days: int = 7) -> List[dict]:
        """获取最近几天的操作日志"""
        logs = []
        try:
            for log_file in self.log_dir.glob("operations_*.jsonl"):
                with open(log_file, "r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            log = json.loads(line.strip())
                            logs.append(log)
                        except:
                            continue
        except Exception as e:
            self.logger.error(f"读取日志失败: {e}")
        return logs
    
    def export_logs(self, start_date: str, end_date: str, output_file: str) -> bool:
        """导出指定日期范围的日志"""
        try:
            logs = self.get_recent_logs(365)  # 获取所有
            filtered = [
                log for log in logs
                if start_date <= log["timestamp"][:10] <= end_date
            ]
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(filtered, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"导出日志失败: {e}")
            return False


# 全局日志管理器实例
log_manager = LogManager()