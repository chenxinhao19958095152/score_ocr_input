# -*- coding: utf-8 -*-
"""
成绩自动录入辅助工具 - 配置管理模块
"""
import os
import json
from pathlib import Path

# 项目根目录
PROJECT_ROOT = Path(__file__).parent.parent

# 配置文件路径
CONFIG_FILE = PROJECT_ROOT / "grade_tool_config.json"
LOG_DIR = PROJECT_ROOT / "logs"
TEMPLATE_DIR = PROJECT_ROOT / "templates"

# 默认配置
DEFAULT_CONFIG = {
    "app": {
        "name": "成绩自动录入辅助工具",
        "version": "1.0.0",
        "author": "中职电子专业学生"
    },
    "ocr": {
        "engine": "rapidocr",  # 可选: rapidocr, tesseract
        "lang": "ch",
        "use_gpu": False,
        "confidence_threshold": 0.7
    },
    "excel": {
        "default_sheet": "成绩表",
        "name_col": "姓名",
        "id_col": "学号",
        "subject_cols": {},  # 科目 -> 列名映射
        "exam_type_row": 1,  # 考试类型所在行
    },
    "validation": {
        "filename_match_enabled": True,
        "duplicate_check_enabled": True,
        "duplicate_action": "ask",  # ask, overwrite, skip
        "fuzzy_name_match": True,
        "fuzzy_threshold": 0.85
    },
    "ui": {
        "window_width": 1200,
        "window_height": 800,
        "theme": "light"
    },
    "phone_sync": {
        "enabled": False,
        "port": "COM3",
        "baudrate": 115200,
        "timeout": 1
    },
    "logging": {
        "level": "INFO",
        "max_file_size": 10 * 1024 * 1024,  # 10MB
        "backup_count": 5
    }
}

# 考试类型标准化映射
EXAM_TYPE_MAPPING = {
    "周测": ["周测", "周考", "weekly", "周练"],
    "第一次月考": ["第一次月考", "1月考", "月考一", "第一月考", "monthly 1"],
    "第二次月考": ["第二次月考", "2月考", "月考二", "第二月考", "monthly 2"],
    "第三次月考": ["第三次月考", "3月考", "月考三", "第三月考", "monthly 3"],
    "期中": ["期中", "期中考试", "midterm", "中考"],
    "期末": ["期末", "期末考试", "final", "期终"],
    "模拟考": ["模拟考", "模拟", "mock"],
    "其他": ["其他", "other"]
}

# 支持的文件格式
SUPPORTED_IMAGE_FORMATS = [".jpg", ".jpeg", ".png", ".bmp", ".webp"]
SUPPORTED_DOC_FORMATS = [".pdf"]
SUPPORTED_FORMATS = SUPPORTED_IMAGE_FORMATS + SUPPORTED_DOC_FORMATS

# 标准科目列表（可扩展）
STANDARD_SUBJECTS = [
    "语文", "数学", "英语", "物理", "化学", "生物", "历史", "地理", "政治",
    "电子", "计算机", "编程", "电工", "电子技术", "单片机", "PLC",
    "体育", "音乐", "美术", "信息技术", "通用技术"
]


def load_config():
    """加载配置文件"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                user_config = json.load(f)
            # 合并默认配置
            return merge_config(DEFAULT_CONFIG, user_config)
        except Exception as e:
            print(f"配置加载失败，使用默认配置: {e}")
    return DEFAULT_CONFIG.copy()


def save_config(config):
    """保存配置文件"""
    try:
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"配置保存失败: {e}")
        return False


def merge_config(default, user):
    """递归合并配置"""
    result = default.copy()
    for key, value in user.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_config(result[key], value)
        else:
            result[key] = value
    return result


def get_exam_type_standard(raw_text):
    """将OCR识别的考试类型文本标准化"""
    raw_text = raw_text.strip()
    for standard, variants in EXAM_TYPE_MAPPING.items():
        for variant in variants:
            if variant in raw_text:
                return standard
    return "其他"


def ensure_dirs():
    """确保必要目录存在"""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)