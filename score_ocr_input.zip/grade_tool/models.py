# -*- coding: utf-8 -*-
"""
成绩自动录入辅助工具 - 数据模型
"""
import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum
import uuid


class ExamType(Enum):
    """考试类型枚举"""
    WEEKLY = "周测"
    MONTHLY_1 = "第一次月考"
    MONTHLY_2 = "第二次月考"
    MONTHLY_3 = "第三次月考"
    MIDTERM = "期中"
    FINAL = "期末"
    MOCK = "模拟考"
    OTHER = "其他"


class DuplicateAction(Enum):
    """重复记录处理动作"""
    OVERWRITE = "覆盖旧成绩"
    SKIP = "跳过本条记录"
    CANCEL = "取消录入"


@dataclass
class Student:
    """学生信息"""
    name: str
    student_id: str = ""
    row_index: int = -1  # Excel中的行索引
    extra_info: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ScoreRecord:
    """成绩记录"""
    student_name: str
    subject: str
    exam_type: str
    score: str
    raw_ocr: str = ""
    phone_time: str = ""
    record_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    student_id: str = ""
    source: str = "ocr"  # ocr, phone, manual
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "student_name": self.student_name,
            "subject": self.subject,
            "exam_type": self.exam_type,
            "score": self.score,
            "raw_ocr": self.raw_ocr,
            "phone_time": self.phone_time,
            "record_id": self.record_id,
            "timestamp": self.timestamp,
            "student_id": self.student_id,
            "source": self.source
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ScoreRecord':
        """从字典创建"""
        return cls(
            student_name=data.get("student_name", ""),
            subject=data.get("subject", ""),
            exam_type=data.get("exam_type", ""),
            score=data.get("score", ""),
            raw_ocr=data.get("raw_ocr", ""),
            phone_time=data.get("phone_time", ""),
            record_id=data.get("record_id", str(uuid.uuid4())[:8]),
            timestamp=data.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            student_id=data.get("student_id", ""),
            source=data.get("source", "ocr")
        )
    
    def get_key(self) -> str:
        """获取唯一标识键：学生姓名+科目+考试类型"""
        return f"{self.student_name}|{self.subject}|{self.exam_type}"


@dataclass
class OCRResult:
    """OCR识别结果"""
    exam_type: str = ""
    subject: str = ""
    records: List[ScoreRecord] = field(default_factory=list)
    raw_text: str = ""
    confidence: float = 0.0
    source_file: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "exam_type": self.exam_type,
            "subject": self.subject,
            "records": [r.to_dict() for r in self.records],
            "raw_text": self.raw_text,
            "confidence": self.confidence,
            "source_file": self.source_file,
            "timestamp": self.timestamp
        }


@dataclass
class ValidationResult:
    """校验结果"""
    is_valid: bool
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    duplicate_records: List[ScoreRecord] = field(default_factory=list)
    duplicate_names: List[Student] = field(default_factory=list)
    
    def has_warning(self) -> bool:
        return len(self.warnings) > 0
    
    def has_error(self) -> bool:
        return len(self.errors) > 0
    
    def get_status(self) -> str:
        if self.has_error():
            return "error"
        elif self.has_warning():
            return "warning"
        return "ok"


@dataclass
class LogEntry:
    """日志条目"""
    timestamp: str
    action: str  # insert, update, overwrite, skip, delete, import
    operator: str  # user, system, phone
    record: ScoreRecord
    old_record: Optional[ScoreRecord] = None
    details: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "action": self.action,
            "operator": self.operator,
            "record": self.record.to_dict(),
            "old_record": self.old_record.to_dict() if self.old_record else None,
            "details": self.details
        }


@dataclass
class PhoneMessage:
    """手机端通信消息"""
    exam_type: str
    subject: str
    student_name: str
    score: str
    raw_ocr: str
    time: str
    
    @classmethod
    def from_json(cls, json_str: str) -> 'PhoneMessage':
        data = json.loads(json_str.strip())
        return cls(
            exam_type=data.get("exam_type", ""),
            subject=data.get("subject", ""),
            student_name=data.get("student_name", ""),
            score=data.get("score", ""),
            raw_ocr=data.get("raw_ocr", ""),
            time=data.get("time", "")
        )
    
    def to_json(self) -> str:
        return json.dumps({
            "exam_type": self.exam_type,
            "subject": self.subject,
            "student_name": self.student_name,
            "score": self.score,
            "raw_ocr": self.raw_ocr,
            "time": self.time
        }, ensure_ascii=False) + "\n"


@dataclass
class PhoneResponse:
    """手机端响应消息"""
    status: str  # ok, warn_dup_name, warn_dup_record
    warn: str = ""
    
    def to_json(self) -> str:
        return json.dumps({
            "status": self.status,
            "warn": self.warn
        }, ensure_ascii=False) + "\n"